/**
 * Задание, в принципе, очень простое.
 * думаю с набитой рукой  это задание бы делалось у меня часа 3-4, с учетом перерыва на кофе.
 * Это мой первый опыт с PIXI, до этого просто смотрел код примеров.
 * JS - всегда был для меня вспомогательным инструментом на работе,
 * основы я его знаю, но применял постольку по скольку, обычно использовал jQuery.
 * Думаю, что могу делать лучше, быстрее и каечственней, если поднабраться опыта в этой сфере.
 * На это задание я потратил примерно чаов 8 (два вечера)
 * Ниже оставил комментарии, где я бы хотел узнать больше,
 * как бы работает как описано, но ... мне не нравится решения мои из-за недостатка опыта.
 */
let width = 1390;
let height = 640;
let size = [1390, 640];
var ratio = size[0] / size[1];

app = new PIXI.Application({
    width: width,
    height: height,
    transparent: true,
    autoResize: true,
    resolution: devicePixelRatio
});
document.body.appendChild(app.view);

const roomSprite = PIXI.Sprite.from('img/room.jpg');
roomSprite.anchor.set(1, 1);
roomSprite.x = app.screen.width;
roomSprite.y = app.screen.height;
app.stage.addChild(roomSprite);
//статичные объекты комнаты
//подумал, что правильно будет выставить все объекты комнаты
//а не просто фоном на одной картинке, но по заданию быстрее было бы с фоном.
let roomOjcts = [
    ['img/sofa.png', 128.71, 321.61],
    ['img/table.png', 202, 196],
    ['img/globe.png', 87, 113],
    ['img/plant.png', 456, -40],
    ['img/book_stand.png', 837.34, -3],
    ['img/plant.png', 1135, 164],
    ['img/Austin.png', 695, 107],
];
roomOjcts.forEach((v) => {
    let sprite = PIXI.Sprite.from(v[0]);
    sprite.x = v[1];
    sprite.y = v[2];
    app.stage.addChild(sprite);
});

const stairway = PIXI.Sprite.from('img/old_stair.png');
stairway.anchor.set(1, 0);
stairway.x = app.view.width;
stairway.y = 48;
app.stage.addChild(stairway);

let newStairway=[];
for(let i=0;i<3;i++) {
    let s = PIXI.Sprite.from(`img/new_stair_0${i+1}.png`);
    s.anchor.set(1, 0);
    s.x = app.view.width;
    //Хотелось бы лестницу как-то более акуратно выставлять, при выборе картинку
    //Долго подбирал позицию, но всё как-то несуразно, я бы тут просил рекомендаций дизайнера
    s.y = -100;
    s.alpha = 0;
    app.stage.addChild(s);
    newStairway.push(s);
}

const ficus = PIXI.Sprite.from('img/ficus.png');
ficus.anchor.set(1, 1);
ficus.x = app.view.width;
ficus.y = app.view.height;
app.stage.addChild(ficus);

const hammer = PIXI.Sprite.from('img/icon_hammer.png');
hammer.alpha = 0;
hammer.x = 1087;
hammer.y = 258;
hammer.on('pointerdown', hammerClick);
app.stage.addChild(hammer);

const finalScene = PIXI.Sprite.from('img/final.png');
finalScene.anchor.set(1, 1);
finalScene.x = app.screen.width;
finalScene.y = app.screen.height;
finalScene.alpha = 0;
app.stage.addChild(finalScene);

let logo = PIXI.Sprite.from('img/logo.png');
logo.x = 15;
logo.y = 15;
app.stage.addChild(logo);

setTimeout(function () {
    app.ticker.add(() => {
        hammer.alpha += 0.02;
    });
    hammer.interactive = true;
    hammer.buttonMode = true;
}, 3000);

function hammerClick() {
    //Набор элементов меню
    let sw = [];
    for (let i = 0; i < 3; i++) {
        let s =  PIXI.Sprite.from('img/select_window.png');
        s.x =  852 + i*130;
        s.y = 10;
        s.alpha = 0;
        s.interactive = true;
        s.buttonMode = true;
        s.on('pointerover', onButtonOver)
         .on('pointerout', onButtonOut)
         .on('pointerdown', onClickOk);
        app.stage.addChild(s);
        sw.push(s);
    }
    //Подсветка активного элемента меню
    const active = PIXI.Sprite.from('img/select_window_active.png');
    active.alpha = 0;
    app.stage.addChild(active);
    //Набор лесенок в элементах меню
    let si = [];
    for (let i = 0; i < 3; i++) {
        let s = PIXI.Sprite.from(`img/stair_ico_${i+1}.png`);
        s.x = sw[i].x;
        s.y = sw[i].y;
        s.alpha = 0;
        app.stage.addChild(s);
        si.push(s);
    }
    app.ticker.add(() => {
        for (let i = 0; i < 3; i++) {
            sw[i].alpha += 0.026;
            si[i].alpha += 0.026;
        }
    });
    hammer.interactive = false;
    hammer.buttonMode = false;
    app.ticker.add(() => {
        hammer.alpha -= 0.4;
    });

    const okButton = PIXI.Sprite.from('img/ok.png');
    okButton.alpha = 0;
    okButton.interactive = true;
    okButton.buttonMode = true;
    app.stage.addChild(okButton);

    function onButtonOver() {
        let x = this.x;
        let y = this.y;
        let i = 0;
        active.x = x;
        active.y = y;
        active.alpha = 1;
        okButton.x = x-10;
        okButton.y = y+112;
        okButton.alpha = 1;
        // лучше не придумал как сделать
        // хотелось бы получать какой-то ID
        // и по ID брать уже лестницу, без циклов
        si.find(function (item, index, array) {
            if(x == item.x && y == item.y) {
                i = index
                return true;
            }
        });
        for(item of newStairway) {
            item.alpha = 0;
        }
        newStairway[i].alpha = 1;
    }

    function onButtonOut() {
        for(item of newStairway) {
            item.alpha = 0;
        }

    }

    function onClickOk() {
        app.stage.removeChild(okButton);
        app.stage.removeChild(active);
        app.stage.removeChild(hammer);
        app.stage.removeChild(stairway);
        for (let i = 0; i < 3; i++) {
            app.stage.removeChild(sw[i]);
            app.stage.removeChild(si[i]);
        }
        app.ticker.add(() => {
            // лучше не придумал как сделать
            // хотелось бы получать какой-то ID
            // и по ID брать уже лестницу, без циклов
            for (let i = 0; i < 3; i++) {
                if(newStairway[i].y<28) {
                    newStairway[i].y += 4;
                }
            }
        });
        //и это решение мне не нравится.
        //не разобрался как очередность
        //через промиси выставить. для тикеров.
        //не ясно как очередь посмотреть анимации
        app.ticker.add(() => {
            if(newStairway[0].y>=28) {
                finalScene.alpha += 0.02;
            }
        });
    }
}

const btn = PIXI.Sprite.from('img/btn.png');
btn.anchor.set(1, 1);
btn.x = (app.view.width / 2) + 182;
btn.y = app.view.height - 20;
btn.interactive = true;
btn.buttonMode = true;
btn.on('pointerdown', btnClick);
app.stage.addChild(btn);

function btnClick() {
    location.href = "http://playable.playrix.com/demo/HS/";
};

function resize() {
    if (window.innerWidth / window.innerHeight >= ratio) {
        var w = window.innerHeight * ratio;
        var h = window.innerHeight;
    } else {
        var w = window.innerWidth;
        var h = window.innerWidth / ratio;
    }
    app.view.style.width = w + 'px';
    app.view.style.height = h + 'px';
}
resize();
window.onresize = resize;